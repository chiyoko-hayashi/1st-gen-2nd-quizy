<?php
  $id = $_GET['id'];
  echo $id;

// echo phpinfo();

// 以下の参考url　http://www.flatflag.nir87.com/pdo_construct-912
    // データベースに接続するために必要なデータソースを変数に格納
    // mysql:host=ホスト名;dbname=データベース名;charset=文字エンコード
    $dsn = 'mysql:host=db;dbname=mysql';
    
    // データベースのユーザー名
        $user = 'root';
    
    // データベースのパスワード
        $password = 'root_pass_fB3uWvTS';
    
    // tryにPDOの処理を記述
    try {
    
    // PDOインスタンスを生成
    $dbh = new PDO($dsn, $user, $password);
    echo "接続成功\n";
    // エラー（例外）が発生した時の処理を記述
    } catch (PDOException $e) {
    
    // エラーメッセージを表示させる
    echo 'データベースにアクセスできません！' . $e->getMessage();
    
    // 強制終了
    exit;
    
    }
    ?>