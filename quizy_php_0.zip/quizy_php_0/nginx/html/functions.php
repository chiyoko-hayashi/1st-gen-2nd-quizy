<?php
$id = $_GET['id'];
$pdo = new PDO(
  'mysql:host=db;dbname=mysql;charset=utf8mb4',
  'root',
  'root_pass_fB3uWvTS',
  [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
    ]
  );
  try{
    $stmt = $pdo->prepare("select questions.id, questions.name, choices.name as choices_name, choices.valid 
    from questions 
    inner join choices on questions.id = choices.question_id
    where questions.id = ?");
    $stmt->execute(array($id));
    $question = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $choices_name = array_column($question,'choices_name');
    $choices_name = array_chunk($choices_name,3);
    $json_array = json_encode($choices_name);
  }catch (PDOException $e) {
    echo $e->getMessage() . PHP_EOL;
    exit;
  }
  
  // $stmt = $pdo->prepare("SELECT name FROM choices where question_id =:id");
  // $stmt->bindValue(':id', $id, PDO::PARAM_INT);
  // $stmt->execute();
  // $choices = $stmt->fetchAll();
  // $choices = array_column($choices,'name');
  // $choices = array_chunk($choices,3);
  // $json_array = json_encode($choices);
  // print_r($choices);