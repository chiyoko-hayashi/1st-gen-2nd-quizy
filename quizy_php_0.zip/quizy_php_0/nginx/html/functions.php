<?php
$id = $_GET['id'];
$pdo = new PDO(
  'mysql:host=db;dbname=mysql;charset=utf8mb4',
  'root',
  'root_pass_fB3uWvTS',
  [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
    ]
  );
  $stmt = $pdo->query("SELECT name FROM questions where id = $id");
  $questions = $stmt->fetchAll();  
  $stmt = $pdo->query("SELECT name FROM choices where question_id = $id");
  $choices = $stmt->fetchAll();
  $choices = array_column($choices,'name');
  $choices = array_chunk($choices,3);
  $json_array = json_encode($choices);