<?php 
// function get_title($questions){
//   $question_names = array_map(function($question){ return $question['name'];}, $questions);
//   return implode(",", $question_names);
// };

// function get_title($question){
//   return $question['name'];
// };

?>