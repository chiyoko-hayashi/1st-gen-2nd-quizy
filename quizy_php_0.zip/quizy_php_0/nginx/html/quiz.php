<?php
require('./functions.php');
require('./view_helper.php')
?>

<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title><?=
// get_title($question);
$question['name'];
?></title>
<link href="https://storage.googleapis.com/google-code-archive-downloads/v2/code.google.com/html5resetcss/html5reset-1.6.css">
<link rel="stylesheet" href="./quizy.css">
</head>

<header>
<div class = "header_left">
<h4>kuizy</h4>
</div>
<div class = "header_right">
<a href="/ranking" class="icon">
<img src="https://d1khcm40x1j0f.cloudfront.net/static/img/tab/tournament-on.png" alt="ランキング">
<span>ランキング</span>
</a>

<a href="/quiz/prepare" class="icon">
<img src="https://d1khcm40x1j0f.cloudfront.net/static/img/tab/create-on.png" alt="クイズ作成">
<span>作ってみる</span>
</a>


<a href="/search" class="icon">
<img src="https://d1khcm40x1j0f.cloudfront.net/static/img/tab/search-on.png" alt="検索">
<span>検索する</span>
</a>
</div>
</header>

<body>
<script>
let question_list = <?php echo $json_array; ?>
</script>
<script>
let city_id = <?php echo $id; ?>
</script>
<div id="main" class="main">
<script src="./quizy.js"></script>
</div>
</body>

</html>



